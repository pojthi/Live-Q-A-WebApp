FactoryGirl.define do
  factory :question do
    content "My Question"
  end

end
