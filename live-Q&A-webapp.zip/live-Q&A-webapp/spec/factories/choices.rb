FactoryGirl.define do
  factory :choice do
    content "Yes"

    factory :choice_2 do
      content "No"
    end

    factory :choice_3 do
      content "Maybe"
    end

  end
end
