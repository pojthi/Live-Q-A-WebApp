FactoryGirl.define do
  factory :voter do
    
  end

end
