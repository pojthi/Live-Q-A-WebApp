FactoryGirl.define do
  factory :vote do
    
  end

end
