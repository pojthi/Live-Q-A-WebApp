$(".events.index").ready(function() {
		$(".one").css("width","0%");
		$('.one').animate({"width":"10%"},2000);
		$('.one').animate({"width":"17%"},2000);
		$('.one').animate({"width":"30%"},1000);
		$('.one').animate({"width":"40%"},1500);
		$('.one').animate({"width":"46%"},1500);
		$('.one').animate({"width":"57%"},2500);
		$('.one').animate({"width":"100%"},1800);

		$(".two").css("width","0%");
		$('.two').animate({"width":"7%"},1200);
		$('.two').animate({"width":"8%"},2500);
		$('.two').animate({"width":"9%"},1000);
		$('.two').animate({"width":"13%"},1300);
		$('.two').animate({"width":"23%"},1200);
		$('.two').animate({"width":"32%"},1600);

		$(".three").css("width","0%");
		$('.three').animate({"width":"3%"},1500);
		$('.three').animate({"width":"4%"},1600);
		$('.three').animate({"width":"5%"},1000);
		$('.three').animate({"width":"9%"},1700);
		$('.three').animate({"width":"13%"},1000);
		$('.three').animate({"width":"22%"},1300);
});